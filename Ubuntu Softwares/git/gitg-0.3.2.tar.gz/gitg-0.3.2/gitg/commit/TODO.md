# To implement
* Rendering of permission changes
* Selecting multiple files
* DND

* External diff
  This is currently not possible with libgit2.

* Graceful handling of merge conflicts in the index.
Bug 603585 - When a merge conflic is commited, gitg taints the status

# To check
* Handling of binary files/diffs
* Support for symbolic links
