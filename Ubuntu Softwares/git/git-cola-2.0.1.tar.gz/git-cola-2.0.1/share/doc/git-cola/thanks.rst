Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Cook
* Alex Chernetz
* Alexander Kozienko
* Andreas Sommer
* Audrius Karabanovas
* Barry Roberts
* Boris W
* Ben Boeckel
* Benoît Nouyrigat
* Christian Jann
* Christopher Meng
* Daniel King
* Daniel Fahlke
* David Aguilar
* David Martínez Martí
* Dennis Gilmore
* Eric Drechsel
* `GIT Hackers <http://git-scm.com/about>`_
* Glen Mailer
* Guillaume de Bure
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jakub Wilk
* Jérôme Carretero
* Johann Schmitz
* Jeff Dagenais
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Libor Jelinek
* Maciej Filipiak
* Mahmoud Hossam
* Maicon D. Filippsen
* Marco Costalba
* Markus Heidelberg
* Maarten Nieber
* Matthew Levine
* Michael Geddes
* Michael Homer
* Minarto Margoliono
* Nicolas Dietrich
* Omega Weapon
* Owen Healy
* Paolo G. Giarrusso
* Peter Júnoš
* Rustam Safin
* Sergey Leschina
* Srinivasa Nallapati
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Sven Claussner
* Taylor Braun-Jones
* Ugo Riboni
* Uri Okrent
* Virgil Dupras
